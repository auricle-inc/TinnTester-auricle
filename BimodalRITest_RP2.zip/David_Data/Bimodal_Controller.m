
%% Grab attenuator
%'C:\TDT\lib64\PA5x.ocx'

RP2_1 = -1;

PA5 = actxcontrol('PA5.x','Position',[1160,758,1256,790]);


success = PA5.ConnectPA5('USB',1);

if ~success
    msgbox('Error Connecting to PA5')
    release(PA5);
else
    %Configure attenuator properties
    PA5_cur_atten = 120;
    PA5.SetAtten(PA5_cur_atten);
end

%% Grab RP2.1 Processor
RP2_1 = -1;
if success == 1
    ZBus = actxcontrol('ZBUS.x',[1 1 1 1]);
    success = invoke(ZBus,'ConnectZBUS','USB');
    if success == 0
        msgbox('Failed to init ZBus');
        RP2_1 = -1;
        release(ZBus);
        delete(ZBus);
    end
    
    if success == 1
        RCODIR='C:\TinData\TDT Treatment Generator';
        RP2_1 = actxcontrol('RPco.X',[5 5 26 26]);
        
        success = RP2_1.ConnectRP2('USB',1);
        %success = handles.RP2_1.ConnectRZ2('USB',1);
        
        if success == 0
            msgbox('Error Connecting to Processor')
            RP2_1 = -1;
        end
        
    else
        msgbox('Failed to connect to stimulator.')
        RP2_1 = -1;
        
    end
else
    
    RP2_1 = -1;
end

if RP2_1 == -1;
    return;
end


Fs = RP2_1.GetSFreq();
trial_dur = 160;
treat_samps = 9776; %This should be the length of the Treatment_Stimulus file
sample_time = 1000/(2*48828.125);

intervals = repmat([-20 -10 -5 5 10 20],1,2);
order = randsample(numel(intervals),numel(intervals),false);
intervals = intervals(order);

stim_duration = 10; %Length of audio pulse
elec_dur = 3; %number of stimulus pulses
elec_int = 2; %Amount of current required

treat_dur = 20;
dur_mod = trial_dur - 150; %This should be set such that 

success = RP2_1.LoadCOF([RCODIR  '\TDT_Treatment_Generator_Human.rcx']); %
if ~success
    msgbox('(Failed to init RP2); Restart application to run treatment');
    return;
end
invoke(RP2_1,'Run');

pause(0.2);

success = RP2_1.SetTagVal('AudioGate',1);

success = RP2_1.SetTagVal('Trial_Dur',dur_mod);
if ~success
    msgbox('Failure to set trial duration')
end

success = RP2_1.SetTagVal('SampleTime',sample_time); %48828.125  195312.5  97656.25
if ~success
    msgbox('Failure to set sample rate')
    
end

success = RP2_1.SetTagVal('SampleCount',handles.treat_samps-1);


if delay <= 0
    delay = delay*-1 + stim_duration;
else
    delay = delay*-1;
end

%The audio pulse will always start at 50 ms relative to the onset of the
%trial --> This ensures that the RP2_1 has enough time to set everything up
%properly
success = RP2_1.SetTagVal('Delay',50+delay);
if ~success
    msgbox('Failure to set electrical delay')
end

success = RP2_1.SetTagVal('NumPulse',elec_dur);
if ~success
    msgbox('Failure to set pulse count')
end


success = RP2_1.SetTagVal('CurrentVal',elec_int);
if ~success
    msgbox('Failure to set current level')
end


PA5.SetAtten(0);
PA5_cur_atten = 0;
success = RP2_1.SetTagVal('Run',1);

if success == 0
    RP2_1.SetTagVal('Run',0);
    success = RP2_1.SetTagVal('CurrentVal',0);
    success = RP2_1.SetTagVal('AudioGate',0);
    invoke(RP2_1,'Halt');
    PA5.SetAtten(120);
    PA5_cur_atten = 120;

    % Update handles structure
    msgbox('Error in Parameter Setting');
    uiwait;
    return;
    
end

trial_counter = 0;
store_dur = 0;
cur_time = 0;

total_time = treat_dur*60;
sec_count = 0;
%     time_vector = zeros(10000,1);
%     time_idx = 1;

old_trial_counter = 0;
new_trial_counter = 0;
tic;

stim_val = elec_int;
time = toc;
while time <= (total_time)
    
    drawnow;
    
    time = toc;
end


disp(['time: ' num2str(time)]);

success = RP2_1.SetTagVal('AudioGate',0);
success = RP2_1.SetTagVal('CurrentVal',0);
RP2_1.SetTagVal('Run',0);
invoke(RP2_1,'Halt');
PA5.SetAtten(120);
PA5_cur_atten = 120;

drawnow;
